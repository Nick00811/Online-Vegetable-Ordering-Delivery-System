-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 28, 2023 at 08:24 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `veg`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblcard`
--

CREATE TABLE `tblcard` (
  `name` varchar(50) NOT NULL,
  `cardno` varchar(16) NOT NULL,
  `mm` int(11) NOT NULL,
  `yy` int(11) NOT NULL,
  `cvv` int(11) NOT NULL,
  `amount` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcard`
--

INSERT INTO `tblcard` (`name`, `cardno`, `mm`, `yy`, `cvv`, `amount`) VALUES
('abc', '1111222233334444', 10, 23, 789, 20000);

-- --------------------------------------------------------

--
-- Table structure for table `tblcustomer`
--

CREATE TABLE `tblcustomer` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `confirmed` varchar(10) NOT NULL DEFAULT 'Yes'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcustomer`
--

INSERT INTO `tblcustomer` (`id`, `name`, `mobile`, `email`, `address`, `username`, `password`, `confirmed`) VALUES
(1, 'abc', '9880917783', 'abc@gmail.com', 'Bgm', 'abc', 'abc', 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `tbldistributor`
--

CREATE TABLE `tbldistributor` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `regname` varchar(50) NOT NULL,
  `regno` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `confirmed` varchar(10) NOT NULL DEFAULT 'Yes'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbllogin`
--

CREATE TABLE `tbllogin` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbllogin`
--

INSERT INTO `tbllogin` (`username`, `password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `tblorder`
--

CREATE TABLE `tblorder` (
  `id` int(11) NOT NULL,
  `dtdate` date NOT NULL,
  `pid` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `paytype` varchar(20) NOT NULL,
  `distributor` varchar(50) NOT NULL,
  `dispatched` char(1) NOT NULL DEFAULT 'N',
  `qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblorder`
--

INSERT INTO `tblorder` (`id`, `dtdate`, `pid`, `username`, `paytype`, `distributor`, `dispatched`, `qty`) VALUES
(1, '2023-08-21', 2, 'abc', 'Cash on Delivery', 'admin', 'Y', 2),
(2, '2023-08-21', 3, 'abc', 'Cash on Delivery', 'admin', 'Y', 1),
(3, '2023-08-21', 4, 'abc', 'Online', 'admin', 'Y', 3),
(4, '2023-08-21', 1, 'abc', 'Cash on Delivery', 'admin', 'Y', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblproducts`
--

CREATE TABLE `tblproducts` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `brand` varchar(50) NOT NULL,
  `model` varchar(50) NOT NULL,
  `price` float NOT NULL,
  `description` varchar(200) NOT NULL,
  `filename0` varchar(50) NOT NULL,
  `filename1` varchar(50) NOT NULL,
  `filename2` varchar(50) NOT NULL,
  `filename3` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblproducts`
--

INSERT INTO `tblproducts` (`id`, `name`, `type`, `brand`, `model`, `price`, `description`, `filename0`, `filename1`, `filename2`, `filename3`, `username`) VALUES
(1, 'Apple', 'Fruits', 'A-1', 'Kg', 140, 'Reddish and good apples', '19Penguins.jpg', '13Hydrangeas.jpg', '13Chrysanthemum.jpg', '19Desert.jpg', 'admin'),
(2, 'Potato', 'Vegetables', 'Regular Potato', 'Kg', 25, 'Nice', '21Desert.jpg', '21Hydrangeas.jpg', '21Jellyfish.jpg', '21Koala.jpg', 'admin'),
(3, 'Chopped Green Veg', 'Packed Vegetables', 'Roasted', '250gm', 30, 'Chopped green vegetables with all good nutrition', '32Tulips.jpg', '39Chrysanthemum.jpg', '32Koala.jpg', '33Hydrangeas.jpg', 'admin'),
(4, 'Apple cuts', 'Packed Fruits', 'Freezed apple', '500 gm', 120, 'Shilmla apples', '41Jellyfish.jpg', '43Desert.jpg', '43Lighthouse.jpg', '49Penguins.jpg', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `tmpcart`
--

CREATE TABLE `tmpcart` (
  `id` int(11) NOT NULL,
  `ip` varchar(50) NOT NULL,
  `qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tmpcart`
--

INSERT INTO `tmpcart` (`id`, `ip`, `qty`) VALUES
(1, '127.0.0.1', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblcustomer`
--
ALTER TABLE `tblcustomer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbldistributor`
--
ALTER TABLE `tbldistributor`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblorder`
--
ALTER TABLE `tblorder`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblproducts`
--
ALTER TABLE `tblproducts`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblcustomer`
--
ALTER TABLE `tblcustomer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbldistributor`
--
ALTER TABLE `tbldistributor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblorder`
--
ALTER TABLE `tblorder`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tblproducts`
--
ALTER TABLE `tblproducts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
