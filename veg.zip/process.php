<?php
session_start();
include 'config/dbconnection.php';

if($_SESSION['id']==""){
    header('location:checkout.php?m=1');    
    die();
}

if(isset($_GET['type'])){
    $query="select * from tmpcart where ip='{$_SERVER['REMOTE_ADDR']}'";
    $result=mysqli_query($link,$query);
    while($row=mysqli_fetch_assoc($result)){
        $res=mysqli_query($link,"select username from tblproducts where id='{$row['id']}'");
        $r=mysqli_fetch_assoc($res);
        mysqli_query($link,"insert into tblorder(dtdate,pid,username,paytype,distributor,qty) values(now(),'{$row['id']}','{$_SESSION['id']}','Online','{$r['username']}','{$row['qty']}')") or die(mysqli_error($link));
        mysqli_query($link,"delete from tmpcart where id='{$row['id']}' and ip='{$_SERVER['REMOTE_ADDR']}'");
    }
    
    echo "<script> window.location.href='checkout.php?m=2' </script>";
}
if(isset($_GET['type1'])){
    header("location:./online/index.php?amt={$_GET['amt']}");
}

if(isset($_GET['m'])){
    $query="select * from tmpcart where ip='{$_SERVER['REMOTE_ADDR']}'";
    $result=mysqli_query($link,$query);
    while($row=mysqli_fetch_assoc($result)){
        $res=mysqli_query($link,"select username from tblproducts where id='{$row['id']}'");
        $r=mysqli_fetch_assoc($res);
        mysqli_query($link,"insert into tblorder(dtdate,pid,username,paytype,distributor,qty) values(now(),'{$row['id']}','{$_SESSION['id']}','Cash on Delivery','{$r['username']}','{$row['qty']}')") or die(mysqli_error($link));
        mysqli_query($link,"delete from tmpcart where id='{$row['id']}' and ip='{$_SERVER['REMOTE_ADDR']}'");
    }
    
    echo "<script> window.location.href='checkout.php?m=2' </script>";
}


?>
