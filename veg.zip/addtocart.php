<?php

if(isset($_GET['id'])){
    include 'config/dbconnection.php';
    $query="insert into tmpcart values('{$_GET['id']}','{$_SERVER['REMOTE_ADDR']}','{$_GET['qty']}')";
$result=  mysqli_query($link,$query) or die(mysqli_error($link));
if($result){
    header("location:single.php?id={$_GET['id']}");
}else{
    echo "<script> alert('Product cannot be added to cart.')
          window.location.href='single.php?id={$_GET['id']}' </script>";
}
}

?>
