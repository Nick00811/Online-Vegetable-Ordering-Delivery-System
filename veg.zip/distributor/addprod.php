<!DOCTYPE html>
<html>
<head>
<title>Next Gen Shop</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!-- pignose css -->
<link href="../css/pignose.layerslider.css" rel="stylesheet" type="text/css" media="all" />


<!-- //pignose css -->
<link href="../css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- js -->
<script type="text/javascript" src="../js/jquery-2.1.4.min.js"></script>
<!-- //js -->
<!-- cart -->
	<script src="js/simpleCart.min.js"></script>
<!-- cart -->
<!-- for bootstrap working -->
	<script type="text/javascript" src="../js/bootstrap-3.1.1.min.js"></script>
<!-- //for bootstrap working -->
<link href='//fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,700,900,900italic,700italic' rel='stylesheet' type='text/css'>
<script src="../js/jquery.easing.min.js"></script>
</head>
<body>
   <?php
        session_start();
        if($_SESSION['id']==""){
            header("location:/veg/admin");
        }
   ?>
    
<!-- header -->
<div class="header-bot">
	<div class="container">
		<div class="col-md-3 header-left">
			<h1><a href="/veg/admin"><img src="../images/logo3.jpg"></a></h1>
		</div>
	</div>
</div>
<!-- //header-bot -->
<!-- banner -->
<div class="ban-top">
	<div class="container">
		<div class="top_nav_left">
			<nav class="navbar navbar-default">
			  <div class="container-fluid">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
				  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				  </button>
				</div>
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse menu--shylock" id="bs-example-navbar-collapse-1">
				  <ul class="nav navbar-nav menu__list">
					<li><a class="menu__link" href="index.php">Home<span class="sr-only">(current)</span></a></li>
                                        <li class="active menu__item menu__item--current"><a class="menu__link" href="addprod.php">New Product</a></li>
                                         <li><a class="menu__link" href="order.php">Orders</a></li>
<!--                                        <li><a class="menu__link" href="report.php">Sales Report</a></li>-->
                                        <li><a class="menu__link" href="logout.php">Logout</a></li>
				  </ul>
				</div>
			  </div>
			</nav>	
		</div>
	</div>
</div>
<!-- //banner-top -->
<Center>

    <div class="product-easy">
                <h1>Add New Product</h1>
                <form name="f" method="post" action=""  enctype="multipart/form-data">
                        <div class="contact-form2">
                                <input type="text" placeholder="Vegetable/Fruit Name" name="name" title="Please check the name" autofocus required style="width:300px;"/><br/><br/>
                                <Select placeholder="Product type" name="type" required style="width:300px;">
                                    <option>Fruits</option>
                                    <option>Vegetables</option>
                                    <option>Packed Fruits</option>
                                    <option>Packed Vegetables</option>
                                </select><br/><br/>
                                <input type="text" placeholder="Category" name="brand" required style="width:300px;"/><br/><br/>
                                <input type="text" placeholder="Packing Type" name="model" required style="width:300px;"/><br/><br/>
                                <input type="text" placeholder="Price" pattern="[0-9]+$" name="price" required style="width:300px;"/><br/><br/>
                                <textarea placeholder="Product Description" name="description" required style="width:300px;"></textarea><br/><br/>
                                <input type="file" name="f0" title="Atleast one image to be uploaded" required /><br/><br/>
                                <input type="file" name="f1" accept="image/gif, image/jpeg, image/png"/><br/><br/>
                                <input type="file" name="f2" accept="image/gif, image/jpeg, image/png"/><br/><br/>
                                <input type="file" name="f3" accept="image/gif, image/jpeg, image/png"/><br/><br/>
                                <input type="submit" value="Submit" class="item_add hvr-outline-out button2" name="save"/>
                        </div><br/><br/>
                </form>
    </div>
    
    <?php
       include '../config/dbconnection.php';
       if(isset($_REQUEST['save'])){
           $query="insert into tblproducts(name,type,brand,model,price,description,username) values('{$_POST['name']}','{$_POST['type']}','{$_POST['brand']}','{$_POST['model']}','{$_POST['price']}','{$_POST['description']}','{$_SESSION['id']}')";
           $result=mysqli_query($link,$query) or die(mysqli_error($link));
           if($result){
               $query="Select max(id) as id from tblproducts where username='{$_SESSION['id']}'";
               $result=mysqli_query($link,$query);
               $row=mysqli_fetch_assoc($result);
               
               $f0=$row['id'].$_FILES["f0"]["name"];
               if ($_FILES["f1"]["tmp_name"]!="")
                    $f1=$row['id'].$_FILES["f1"]["name"];
               if($_FILES["f2"]["tmp_name"]!="")
                    $f2=$row['id'].$_FILES["f2"]["name"];
               if($_FILES["f2"]["tmp_name"]!="")
                   $f3=$row['id'].$_FILES["f3"]["name"];
//               if($_FILES["f3"]["tmp_name"]!="")
//                    $f4=$row['id'].$_FILES["f3"]["name"];           
               move_uploaded_file($_FILES["f0"]["tmp_name"],"../productimg/".$f0);
               move_uploaded_file($_FILES["f1"]["tmp_name"],"../productimg/".$f1);
               move_uploaded_file($_FILES["f2"]["tmp_name"],"../productimg/".$f2);
               move_uploaded_file($_FILES["f3"]["tmp_name"],"../productimg/".$f3);
               
               $query="update tblproducts set filename0='$f0',filename1='$f1',filename2='$f2',filename3='$f3' where id='{$row['id']}'";
               $result=mysqli_query($link,$query);
               if(mysqli_affected_rows($link)>0){
                   echo "<script> alert('Product uploaded successfully with images');
                                  window.location.href='addprod.php'; </script>";
               }else{
                   echo "<script> alert('Product not uploaded'); </script>";
               }
           }
           else{
                   echo "<script> alert('Product not added'); </script>";
               }
       }
    ?>
<!-- content-bottom -->
</body>
</html>