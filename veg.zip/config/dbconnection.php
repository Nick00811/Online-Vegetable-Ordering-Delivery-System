<?php

$host="localhost";
$user="root";
$password="";
$dbase="veg";
$link=mysqli_connect($host, $user, $password, $dbase);

?>