<!DOCTYPE html>
<html>
<head>
<title>Next Gen Shop</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!-- pignose css -->
<link href="../css/pignose.layerslider.css" rel="stylesheet" type="text/css" media="all" />


<!-- //pignose css -->
<link href="../css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- js -->
<script type="text/javascript" src="../js/jquery-2.1.4.min.js"></script>
<!-- //js -->
<!-- cart -->
	<script src="../js/simpleCart.min.js"></script>
<!-- cart -->
<!-- for bootstrap working -->
	<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>
<!-- //for bootstrap working -->
<link href='//fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'/>
<link href='//fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,700,900,900italic,700italic' rel='stylesheet' type='text/css'/>
<script src="js/jquery.easing.min.js"></script>
</head>
<body>
<!-- header -->
<div class="header">
	
</div>
<!-- //header -->
<!-- header-bot -->
<div class="header-bot">
	<div class="container">
		<div class="col-md-3 header-left">
			<h1><a href="/veg"><img src="../images/logo3.jpg"></a></h1>
		</div>
	</div>
</div>
<!-- //header-bot -->
<!-- banner -->
<div class="ban-top">
	<div class="container">
		
		<div class="top_nav_right">
			<div class="cart box_1">
                            LOGIN
						
			</div>	
		</div>
		<div class="clearfix"></div>
	</div>
</div><center><br/><br/><h1>Login</h1><br/>
<!-- //banner-top -->
<!-- content -->

<form method="post" action="">
	<div class="contact-form2">
        	<input type="text" placeholder="UserName" name="user" autofocus required style="width:300px;"/><br/><br/>
                <input type="password" placeholder="Password" name="pass" style="width:300px;" required/><br/><br/>
		<input type="submit" value="Submit" name="log" class="item_add hvr-outline-out button2"/>
	</div>
</form>

<?php
    if(isset($_REQUEST['log'])){
        session_start();
        include '../config/dbconnection.php';
        
        $query="Select * from tbllogin where binary username='{$_POST['user']}' and binary password='{$_POST['pass']}'";
        $result=mysqli_query($link,$query);
        if(mysqli_num_rows($result)>0){
            $_SESSION['id']=$_POST['user'];
            header("location:home.php");
        }else{
            echo 'Invalid username/password';
        }
    }
?>

</body>
</html>